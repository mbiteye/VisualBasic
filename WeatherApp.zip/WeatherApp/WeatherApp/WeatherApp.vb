﻿
Imports System.IO
Imports System.Text
Imports System.Net
Public Class WeatherApp

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        System.Environment.Exit(0)
    End Sub

    Private Sub WeatherApp_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Dim webAddress As String = "http://wxdata.weather.com/wxdata/weather/local/USTX1383?cc=*&unit=f"
        Dim client As WebClient = New WebClient()
        Dim xml As String = client.DownloadString("http://wxdata.weather.com/wxdata/weather/local/USTX1383?cc=*&unit=f")
        '  MsgBox(xml)
        lblLoc.Text = parser("dnam", xml)
        lblTime.Text = parser("lsup", xml)
        lblTemp.Text = parser("tmp", xml) & parser("ut", xml)
    End Sub

    Public Function parser(tag As String, xml As String)
        'substring(looking for, how far)
        'substring(10,2)
        Return xml.Substring(xml.IndexOf("<" & tag & ">") + Len(tag) + 2, xml.IndexOf("</" & tag & ">") - (xml.IndexOf("<" & tag & ">") + Len(tag) + 2))

    End Function
End Class
