﻿Public Class Form1

    'The following method handles what happens when button1 is hit
    ' Checks If it is the user's turn to play then it displays "X" on the button and disables it
    'The method also calls the cpu() method for the computer's turn to play
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If play.Text = "X" Then
            Button1.Text = "X"
            Button1.Enabled = False
            play.Text = "O"
            cpu()
        End If

    End Sub

    'The following method handles what happens when button2 is hit
    ' Checks If it is the user's turn to play then it displays "X" on the button and disables it
    'The method also calls the cpu() method for the computer's turn to play
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If play.Text = "X" Then
            Button2.Text = "X"
            Button2.Enabled = False
            play.Text = "O"
            cpu()
        End If
    End Sub

    'The following method handles what happens when button3 is hit
    ' Checks If it is the user's turn to play then it displays "X" on the button and disables it
    'The method also calls the cpu() method for the computer's turn to play
    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        If play.Text = "X" Then
            Button3.Text = "X"
            Button3.Enabled = False
            play.Text = "O"
            cpu()
        End If

    End Sub

    'The following method handles what happens when button4 is hit
    ' Checks If it is the user's turn to play then it displays "X" on the button and disables it
    'The method also calls the cpu() method for the computer's turn to play
    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        If play.Text = "X" Then
            Button4.Text = "X"
            Button4.Enabled = False
            play.Text = "O"
            cpu()
        End If

    End Sub

    'The following method handles what happens when button5 is hit
    ' Checks If it is the user's turn to play then it displays "X" on the button and disables it
    'The method also calls the cpu() method for the computer's turn to play
    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        If play.Text = "X" Then
            Button5.Text = "X"
            Button5.Enabled = False
            play.Text = "O"
            cpu()
        End If

    End Sub

    'The following method handles what happens when button6 is hit
    ' Checks If it is the user's turn to play then it displays "X" on the button and disables it
    'The method also calls the cpu() method for the computer's turn to play
    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        If play.Text = "X" Then
            Button6.Text = "X"
            Button6.Enabled = False
            play.Text = "O"
            cpu()
        End If

    End Sub

    'The following method handles what happens when button7 is hit
    ' Checks If it is the user's turn to play then it displays "X" on the button and disables it
    'The method also calls the cpu() method for the computer's turn to play
    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        If play.Text = "X" Then
            Button7.Text = "X"
            Button7.Enabled = False
            play.Text = "O"
            cpu()
        End If

    End Sub

    'The following method handles what happens when button8 is hit
    ' Checks If it is the user's turn to play then it displays "X" on the button and disables it
    'The method also calls the cpu() method for the computer's turn to play
    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        If play.Text = "X" Then
            Button8.Text = "X"
            Button8.Enabled = False
            play.Text = "O"
            cpu()
        End If

    End Sub

    'The following method handles what happens when button9 is hit
    ' Checks If it is the user's turn to play then it displays "X" on the button and disables it
    'The method also calls the cpu() method for the computer's turn to play
    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        If play.Text = "X" Then
            Button9.Text = "X"
            Button9.Enabled = False
            play.Text = "O"
            cpu()
        End If

    End Sub

    Public Sub cpu()
        Dim randNum As New Random  'I declared a random number to figure out where the cpu plays
        Dim myRand As Integer
        Dim bool As Boolean = True 'This boolean variable helps make sure the cpu plays it's turn

        Do While bool
            myRand = randNum.Next(1, 9) 'Here i initialize the random number from 1 to 9

            'The following If statement checks to see if it's the computer's turn to play
            'If it's the computer's turn, random numbers are used to decide where the computer will play
            'After the cpu plays, the button it used is disabled so it cannot be used again
            If play.Text = "O" And myRand = 1 And Button1.Enabled = True Then
                Button1.Text = "O"
                Button1.Enabled = False
                play.Text = "X"
                taunt.Text = "Lucky!"
                bool = False

            ElseIf play.Text = "O" And myRand = 2 And Button2.Enabled = True Then
                Button2.Text = "O"
                Button2.Enabled = False
                play.Text = "X"
                taunt.Text = "Hahahahaha!"
                bool = False

            ElseIf play.Text = "O" And myRand = 3 And Button3.Enabled = True Then
                Button3.Text = "O"
                Button3.Enabled = False
                play.Text = "X"
                taunt.Text = "Giving up yet!?"
                bool = False

            ElseIf play.Text = "O" And myRand = 4 And Button4.Enabled = True Then
                Button4.Text = "O"
                Button4.Enabled = False
                play.Text = "X"
                taunt.Text = "Ooops..."
                bool = False
            ElseIf play.Text = "O" And myRand = 5 And Button5.Enabled = True Then
                Button5.Text = "O"
                Button5.Enabled = False
                play.Text = "X"
                taunt.Text = "Too good for you!"
                bool = False
            ElseIf play.Text = "O" And myRand = 6 And Button6.Enabled = True Then
                Button6.Text = "O"
                Button6.Enabled = False
                play.Text = "X"
                taunt.Text = "Loser!"
                bool = False

            ElseIf play.Text = "O" And myRand = 7 And Button7.Enabled = True Then
                Button7.Text = "O"
                Button7.Enabled = False
                play.Text = "X"
                taunt.Text = "Good Luck."
                bool = False

            ElseIf play.Text = "O" And myRand = 8 And Button8.Enabled = True Then
                Button8.Text = "O"
                Button8.Enabled = False
                play.Text = "X"
                taunt.Text = "Hmmm..."
                bool = False

            ElseIf play.Text = "O" And myRand = 9 And Button9.Enabled = True Then
                Button9.Text = "O"
                Button9.Enabled = False
                play.Text = "X"
                taunt.Text = "Ready to lose"
                bool = False

            Else
                winner() 'Here I call the winner method which determines who won
            End If
        Loop
        winner()

    End Sub

    'The following method uses the tic tac toe rules to determine who won
    'After determining the winner, A message box appears to display the winner and the application is closed
    Public Sub winner()
        If Button1.Text = "X" And Button2.Text = "X" And Button3.Text = "X" Or
            Button4.Text = "X" And Button5.Text = "X" And Button6.Text = "X" Or
            Button7.Text = "X" And Button8.Text = "X" And Button9.Text = "X" Or
            Button1.Text = "X" And Button4.Text = "X" And Button7.Text = "X" Or
            Button2.Text = "X" And Button5.Text = "X" And Button8.Text = "X" Or
            Button3.Text = "X" And Button6.Text = "X" And Button9.Text = "X" Or
            Button1.Text = "X" And Button5.Text = "X" And Button9.Text = "X" Or
            Button3.Text = "X" And Button5.Text = "X" And Button7.Text = "X" Then
            MsgBox("You WIn!")
            System.Environment.Exit(1)

        ElseIf Button1.Text = "O" And Button2.Text = "O" And Button3.Text = "O" Or
            Button4.Text = "O" And Button5.Text = "O" And Button6.Text = "O" Or
            Button7.Text = "O" And Button8.Text = "O" And Button9.Text = "O" Or
            Button1.Text = "O" And Button4.Text = "O" And Button7.Text = "O" Or
            Button2.Text = "O" And Button5.Text = "O" And Button8.Text = "O" Or
            Button3.Text = "O" And Button6.Text = "O" And Button9.Text = "O" Or
            Button1.Text = "O" And Button5.Text = "O" And Button9.Text = "O" Or
            Button3.Text = "O" And Button5.Text = "O" And Button7.Text = "O" Then
            MsgBox("You Lose!")
            System.Environment.Exit(1)

        ElseIf Button1.Enabled = False And Button2.Enabled = False And Button3.Enabled = False And
                Button4.Enabled = False And Button5.Enabled = False And Button6.Enabled = False And
                Button7.Enabled = False And Button8.Enabled = False And Button9.Enabled = False Then
            MsgBox("No WInner!")
            System.Environment.Exit(1)
        End If
    End Sub


End Class
