﻿Imports System.Threading
Public Class Easy
    '  Dim s(15) As Integer
    Dim points As Integer = 0
    Dim turn(1) As Integer
    Dim match(15) As Boolean
    Dim r(16) As Integer
    Dim s As New List(Of Integer)


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Button1.Hide()
        PictureBox1.Visible = True

        If turn(0) < 0 Then
            turn(0) = 0
        Else
            turn(1) = 0
            endturn()
        End If


    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Button2.Hide()
        PictureBox2.Visible = True

        If turn(0) < 0 Then
            turn(0) = 1
        Else
            turn(1) = 1
            endturn()
        End If

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Button3.Hide()
        PictureBox3.Visible = True

        If turn(0) < 0 Then
            turn(0) = 2
        Else
            turn(1) = 2
            endturn()
        End If

    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Button4.Hide()
        PictureBox4.Visible = True

        If turn(0) < 0 Then
            turn(0) = 3
        Else
            turn(1) = 3
            endturn()
        End If

    End Sub
    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Button5.Hide()
        PictureBox5.Visible = True

        If turn(0) < 0 Then
            turn(0) = 4
        Else
            turn(1) = 4
            endturn()
        End If

    End Sub
    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        Button6.Hide()
        PictureBox6.Visible = True

        If turn(0) < 0 Then
            turn(0) = 5
        Else
            turn(1) = 5
            endturn()
        End If

    End Sub
    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        Button7.Hide()
        PictureBox7.Visible = True

        If turn(0) < 0 Then
            turn(0) = 6
        Else
            turn(1) = 6
            endturn()
        End If

    End Sub
    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        Button8.Hide()
        PictureBox8.Visible = True

        If turn(0) < 0 Then
            turn(0) = 7
        Else
            turn(1) = 7
            endturn()
        End If

    End Sub
    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        Button9.Hide()
        PictureBox9.Visible = True

        If turn(0) < 0 Then
            turn(0) = 8
        Else
            turn(1) = 8
            endturn()
        End If

    End Sub
    Private Sub Button10_Click(sender As Object, e As EventArgs) Handles Button10.Click
        Button10.Hide()
        PictureBox10.Visible = True

        If turn(0) < 0 Then
            turn(0) = 9
        Else
            turn(1) = 9
            endturn()
        End If

    End Sub
    Private Sub Button11_Click(sender As Object, e As EventArgs) Handles Button11.Click
        Button11.Hide()
        PictureBox11.Visible = True

        If turn(0) < 0 Then
            turn(0) = 10
        Else
            turn(1) = 10
            endturn()
        End If

    End Sub
    Private Sub Button12_Click(sender As Object, e As EventArgs) Handles Button12.Click
        Button12.Hide()
        PictureBox12.Visible = True

        If turn(0) < 0 Then
            turn(0) = 11
        Else
            turn(1) = 11
            endturn()

        End If

    End Sub
    Private Sub Button13_Click(sender As Object, e As EventArgs) Handles Button13.Click
        Button13.Hide()
        PictureBox13.Visible = True

        If turn(0) < 0 Then
            turn(0) = 12
        Else
            turn(1) = 12
            endturn()
        End If

    End Sub
    Private Sub Button14_Click(sender As Object, e As EventArgs) Handles Button14.Click
        Button14.Hide()
        PictureBox14.Visible = True

        If turn(0) < 0 Then
            turn(0) = 13
        Else
            turn(1) = 13
            endturn()
        End If

    End Sub
    Private Sub Button15_Click(sender As Object, e As EventArgs) Handles Button15.Click
        Button15.Hide()
        PictureBox15.Visible = True

        If turn(0) < 0 Then
            turn(0) = 14
        Else
            turn(1) = 14
            endturn()
        End If

    End Sub
    Private Sub Button16_Click(sender As Object, e As EventArgs) Handles Button16.Click
        Button16.Hide()
        PictureBox16.Visible = True

        If turn(0) < 0 Then
            turn(0) = 15
        Else
            turn(1) = 15
            endturn()
        End If

    End Sub

    Private Sub btnMenu_Click(sender As Object, e As EventArgs) Handles btnMenu.Click
        Splash.Show()
        Me.Hide()
    End Sub

    Private Sub endturn()

        Dim result1, result2 As Integer
        Dim card1, card2 As Integer
        card1 = turn(0)
        card2 = turn(1)
        result1 = s(card1) \ 2
        result2 = s(card2) \ 2

        If result1 = result2 Then
            match(card1) = True
            match(card2) = True
            points = points + 5
        Else
            points = points - 1

            If card1 = 0 Or card2 = 0 Then
                Thread.Sleep(1000)
                Button1.Show()
                PictureBox1.Visible = False
            End If
            If card1 = 1 Or card2 = 1 Then
                Thread.Sleep(1000)
                Button2.Show()
                PictureBox2.Visible = False
            End If
            If card1 = 2 Or card2 = 2 Then
                Thread.Sleep(1000)
                Button3.Show()
                PictureBox3.Visible = False
            End If
            If card1 = 3 Or card2 = 3 Then
                Thread.Sleep(1000)
                Button4.Show()
                PictureBox4.Visible = False
            End If
            If card1 = 4 Or card2 = 4 Then
                Thread.Sleep(1000)
                Button5.Show()
                PictureBox5.Visible = False
            End If
            If card1 = 5 Or card2 = 5 Then
                Thread.Sleep(1000)
                Button6.Show()
                PictureBox6.Visible = False
            End If
            If card1 = 6 Or card2 = 6 Then
                Thread.Sleep(1000)
                Button7.Show()
                PictureBox7.Visible = False
            End If
            If card1 = 7 Or card2 = 7 Then
                Thread.Sleep(1000)
                Button8.Show()
                PictureBox8.Visible = False
            End If
            If card1 = 8 Or card2 = 8 Then
                Thread.Sleep(1000)
                Button9.Show()
                PictureBox9.Visible = False
            End If
            If card1 = 9 Or card2 = 9 Then
                Thread.Sleep(1000)
                Button10.Show()
                PictureBox10.Visible = False
            End If
            If card1 = 10 Or card2 = 10 Then
                Thread.Sleep(1000)
                Button11.Show()
                PictureBox11.Visible = False
            End If
            If card1 = 11 Or card2 = 11 Then
                Thread.Sleep(1000)
                Button12.Show()
                PictureBox12.Visible = False
            End If
            If card1 = 12 Or card2 = 12 Then
                Thread.Sleep(1000)
                Button13.Show()
                PictureBox13.Visible = False
            End If
            If card1 = 13 Or card2 = 13 Then
                Thread.Sleep(1000)
                Button14.Show()
                PictureBox14.Visible = False
            End If
            If card1 = 14 Or card2 = 14 Then
                Thread.Sleep(1000)
                Button15.Show()
                PictureBox15.Visible = False
            End If

            If card1 = 15 Or card2 = 15 Then
                Thread.Sleep(1000)
                Button16.Show()
                PictureBox16.Visible = False
            End If
        End If

        turn(0) = -1 'reset the turn
        turn(1) = -1

        Label1.Text = points

        If match(0) = True And match(1) = True And match(2) = True And
            match(3) = True And match(4) = True And match(5) = True And
            match(6) = True And match(7) = True And match(8) = True And
            match(9) = True And match(10) = True And match(11) = True And
            match(12) = True And match(13) = True And match(14) = True And
            match(15) = True Then
            MsgBox("Winner! Your score is " + CStr(points))
            System.Environment.Exit(0)
        End If


    End Sub
    Dim RandMan As New Random
    Public Function RandNum(lowercase As Integer, uppercase As Integer)
        Return RandMan.Next(lowercase, uppercase)
    End Function
    Private Sub test()
        Dim i() As Image = {My.Resources._1, My.Resources._1, My.Resources._2, My.Resources._2,
            My.Resources._3, My.Resources._3, My.Resources._4, My.Resources._4, My.Resources._5,
            My.Resources._5, My.Resources._6, My.Resources._6, My.Resources._7, My.Resources._7,
            My.Resources._8, My.Resources._8}


        Dim x As Integer
        'MsgBox(r(x))
        Do
            r(x) = RandNum(0, 16)
            If s.Contains(r(x)) = False And r(x) < 16 Then

                s.Add(r(x))
                ' MsgBox(r(x))
            End If
        Loop Until s.Count = 16

        PictureBox1.Image = i(s(0))
        PictureBox2.Image = i(s(1))
        PictureBox3.Image = i(s(2))
        PictureBox4.Image = i(s(3))
        PictureBox5.Image = i(s(4))
        PictureBox6.Image = i(s(5))
        PictureBox7.Image = i(s(6))
        PictureBox8.Image = i(s(7))
        PictureBox9.Image = i(s(8))
        PictureBox10.Image = i(s(9))
        PictureBox11.Image = i(s(10))
        PictureBox12.Image = i(s(11))
        PictureBox13.Image = i(s(12))
        PictureBox14.Image = i(s(13))
        PictureBox15.Image = i(s(14))
        PictureBox16.Image = i(s(15))



        ' End Sub

        ' Private Sub RandomNumbers(s() As Integer)

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Label3.Text = "Hello "
        Label1.Text = points
        turn(0) = -1
        turn(1) = -1
        For i = 0 To 15
            match(i) = False
        Next
        test()

    End Sub


End Class
