﻿Public Class Splash
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Easy.Show()
        Me.Hide()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Medium.Show()
        Me.Hide()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Hard.Show()
        Me.Hide()
    End Sub
End Class